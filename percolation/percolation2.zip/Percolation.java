import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private boolean[] state;
    private WeightedQuickUnionUF uf;
    private int n;
    private int numberOfOpenSites = 0;

    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException();
        }
        this.n = n;
        int size = n * n + 2;
        uf = new WeightedQuickUnionUF(size);
        state = new boolean[size];

        for (int i = 1; i < size; i++)
            state[i] = false;
    }

    public void open(int row, int col) {
        if (row < 1 || col < 1 || row > n || col > n)
            throw new IllegalArgumentException();

        int location1D = (row - 1) * n + col;

        boolean topSide = false;
        boolean bottomSide = false;
        boolean leftSide = false;
        boolean rightSide = false;

        if (row == 1) topSide = true;
        if (row == n) bottomSide = true;
        if (col == 1) leftSide = true;
        if (col == n) rightSide = true;

        if (isOpen(row, col)) {
            return;
        }
        else {
            state[location1D] = true;
            numberOfOpenSites += 1;

            if (topSide) {
                uf.union(0, location1D);
                if (n != 1 && isOpen(row + 1, col))
                    uf.union(col + row * n, location1D);
            }
            else if (bottomSide) {
                if (isOpen(row - 1, col)) uf.union(col + (row - 2) * n, location1D);
                uf.union(n * n + 1, location1D);
            }
            else {
                if (isOpen(row - 1, col)) uf.union(col + (row - 2) * n, location1D);
                if (isOpen(row + 1, col)) uf.union(col + row * n, location1D);
            }

            if (!leftSide) {
                if (isOpen(row, col - 1)) {
                    uf.union(location1D - 1, location1D);
                }
            }
            if (!rightSide) {
                if (isOpen(row, col + 1)) {
                    uf.union(location1D + 1, location1D);
                }
            }
        }

    }

    public boolean isOpen(int row, int col) {
        if (row < 1 || col < 1 || row > n || col > n)
            throw new IllegalArgumentException();
        int location1D = (row - 1) * n + col;
        return state[location1D];
    }

    public boolean isFull(int row, int col) {
        if (row < 1 || col < 1 || row > n || col > n)
            throw new IllegalArgumentException();
        int location1D = (row - 1) * n + col;
        return uf.find(0) == uf.find(location1D) ? true : false;
    }

    public int numberOfOpenSites() {
        return numberOfOpenSites;
    }

    public boolean percolates() {
        return uf.find(0) == uf.find(n * n + 1) ? true : false;
    }


    public static void main(String[] args) {
    }

}
